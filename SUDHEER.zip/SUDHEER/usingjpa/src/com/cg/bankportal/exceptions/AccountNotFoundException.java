package com.cg.bankportal.exceptions;

@SuppressWarnings("serial")
public class AccountNotFoundException extends Exception{

	public AccountNotFoundException()
	{
		super("Account Number not found");
	}

}
