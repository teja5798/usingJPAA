package com.cg.bankportal.exceptions;
@SuppressWarnings("serial")
public class InvalidMailException extends Exception {

	public InvalidMailException()
	{
		super("The Email Format entered is Invalid");
	}

}
