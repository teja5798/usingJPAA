package com.cg.bankportal.exceptions;

@SuppressWarnings("serial")
public class InsuffecientBalanceException extends Exception{

	public InsuffecientBalanceException() {
		super("Insufficient Amount");
	}

}
