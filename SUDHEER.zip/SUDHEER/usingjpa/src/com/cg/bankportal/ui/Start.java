package com.cg.bankportal.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.bankportal.model.Account;
import com.cg.bankportal.service.AccountService;
import com.cg.bankportal.service.AccountServiceImpl;


public class Start {
	static AccountService service=new AccountServiceImpl();
	
	public static void showMenu() {
		System.out.println("Enter your choice:");
		System.out.println("01. Create an Account");
		System.out.println("02. Add Amount to Account");
		System.out.println("03. Show Details");
		System.out.println("04. Transfer Amount");
		System.out.println("05. Show All user Accounts");
		System.out.println("06. Exit");
		System.out.print("Enter Your Choice : ");
	}
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		int choice;
		boolean result;
		while(true)
		{
			showMenu();
			
			choice = scan.nextInt();
			switch(choice)
			{
			case 1:
			
				System.out.println("Account Creation");
				try
				{
					Account useracc=new Account();
					System.out.println("Enter user name:");
					useracc.setName(scan.next());
					System.out.println("Enter user phone number:");
					useracc.setPhoneNumber(scan.nextLong());
					System.out.println("Enter user email:");
					useracc.setEmailId(scan.next());
					useracc.setBalance(0);
					service.createAccount(useracc);
				}
				catch(Exception e)
				
				{
					System.out.println(e);
				}
				break;
			case 2:
				
				System.out.println("Adding amount");
				try {
					System.out.println("Enter the account number:");
					int AccountNumber=scan.nextInt();
					System.out.println("Enter the amount to add in to the account "+AccountNumber);
					int Amount=scan.nextInt();
					result=service.addMoney(AccountNumber, Amount);
					if(result) {
						System.out.println("Amount added successfully");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 3:
			
				System.out.println("View Account Details");
				try
				{
					System.out.println("Enter your Account Number");
					int AccountNumber=scan.nextInt();
					Account user=service.viewAccount(AccountNumber);
					System.out.println("Name="+user.getName()+"\nPhone="+user.getPhoneNumber()+"\nEmail="+user.getEmailId()+"\nBalance="+user.getBalance());
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 4:
				
				System.out.println("Amount Transfer");
				try
				{
					System.out.println("Enter sender Account Number");
					int SenderAccountNumber=scan.nextInt();
					System.out.println("Enter Reciever Account Number");
					int RecieverAccountNumber=scan.nextInt();
					System.out.println("Enter the amount to be transferred");
					int TransferAmount=scan.nextInt();
					result=service.transfer(SenderAccountNumber, RecieverAccountNumber, TransferAmount);
					if(result) {
						System.out.println("Amount transfered successfully");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 5:
			
				System.out.println("Show All user Accounts:\n");
				try
				{	
					List<Account> lists=service.getAllAccounts();
					for (Account account : lists) {
						System.out.println("Account Number: "+account.getAccountNumber()+"\t\tName: "+account.getName());
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 6:
				service.closeFactory();
				System.exit(0);
			default:
				break;
			}
		}
	}

}
