package com.cg.bankportal.service;

import java.util.List;

import com.cg.bankportal.dao.AccountDao;
import com.cg.bankportal.dao.AccountDaoImpl;
import com.cg.bankportal.model.Account;


public class AccountServiceImpl extends Validator implements AccountService{
	AccountDao dao=new AccountDaoImpl();
	Validator v=new Validator();
	int row;

	@Override
	public void createAccount(Account user) throws Exception{
		// TODO Auto-generated method stub
		try 
		{
			v.validator(user);
			dao.createAccount(user);
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	@Override
	public Account viewAccount(int accountNumber) throws Exception{

		try
		{
			return dao.viewAccount(accountNumber);
		}
		catch(Exception e)
		{
			throw e;
		}
	}
	

	@Override
	public boolean addMoney(int accountNumber, int amount) throws Exception{
		// TODO Auto-generated method stub
		try
		{
			return dao.addMoney(accountNumber, amount);
		}
		catch(Exception e)
		{
			throw e;
		}
		
	}
	

	@Override
	public boolean transfer(int accountNumber1, int accountNumber2, int amount) throws Exception {
		// TODO Auto-generated method stub
		try {
			return dao.transfer(accountNumber1, accountNumber2, amount);
			}
		catch(Exception e)
		{
			throw e;
		}
		
	}

	@Override
	public List<Account> getAllAccounts() throws Exception {
		// TODO Auto-generated method stub
		try {
			return dao.getAllAccounts();
		}
		catch(Exception e)
		{
			throw e;
		}
	}
	@Override
	public void closeFactory() {
		dao.closeFactory();
	}
}
