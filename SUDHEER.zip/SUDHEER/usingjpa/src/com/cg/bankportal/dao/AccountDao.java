package com.cg.bankportal.dao;

import java.util.List;

import com.cg.bankportal.model.Account;



public interface AccountDao {
	public void createAccount(Account user);
	public Account viewAccount(int accountNumber) throws Exception;
	public boolean addMoney(int accountNumber, int amount) throws Exception;
	public boolean transfer(int accountNumber1,int accountNumber2, int amount) throws Exception;
	public List<Account> getAllAccounts() throws Exception;
	void closeFactory();
	

}
